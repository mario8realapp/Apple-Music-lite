# Activar login oficial de Apple Music (v1.2)

La interfaz y el botón ya están preparados para usar MusicKit Authentication por reflexión.

1. Descarga el SDK oficial de MusicKit para Android desde Apple Developer.
2. Copia los archivos `.aar`/`.jar` de autenticación necesarios dentro de `app/libs/`.
3. En Apple Developer crea el identificador/clave de MusicKit y genera un Developer Token.
4. Abre `app/src/main/res/values/strings.xml` y reemplaza `PUT_YOUR_APPLE_MUSIC_DEVELOPER_TOKEN_HERE`.
5. Compila de nuevo.

El SDK oficial crea un intent de autenticación con el Developer Token y devuelve un Music User Token al resultado de la actividad.
