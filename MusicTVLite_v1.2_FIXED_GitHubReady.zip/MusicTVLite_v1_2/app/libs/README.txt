Place the official Apple Music MusicKit for Android Authentication SDK AAR/JAR files in this folder.
Download them from Apple Developer > MusicKit > Download the MusicKit SDK for Android.
