package com.mario.musictvlite

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mario.musictvlite.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val appleMusicUrl = "https://music.apple.com/"
    private val authRequestCode = 9001
    private var screen = "home"
    private var authManager: Any? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setupWebView()
        setupButtons()
        setupTvFocusAnimations()
        binding.loginButton.requestFocus()
    }

    private fun setupTvFocusAnimations() {
        val views = listOf(binding.loginButton, binding.openMusicButton, binding.browserButton, binding.donateButton, binding.backHomeButton)
        views.forEach { view ->
            view.setOnFocusChangeListener { v, focused ->
                v.animate().cancel()
                if (focused) {
                    v.animate().scaleX(1.085f).scaleY(1.085f).translationZ(18f).setDuration(140).start()
                    ensureVisible(v)
                } else {
                    v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(120).start()
                }
            }
        }
    }

    private fun ensureVisible(view: View) {
        if (screen == "home") binding.homeScroll.post { binding.homeScroll.smoothScrollTo(0, (view.top - 220).coerceAtLeast(0)) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(binding.webView, true)
        binding.webView.apply {
            setBackgroundColor(Color.BLACK)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    binding.progress.visibility = View.GONE
                    injectTvNavigation()
                    super.onPageFinished(view, url)
                }
            }
            webChromeClient = WebChromeClient()
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                loadsImagesAutomatically = true
                useWideViewPort = true
                loadWithOverviewMode = true
                userAgentString = userAgentString.replace("; wv", "")
            }
        }
    }

    private fun injectTvNavigation() {
        val js = """
        (() => {
          const STYLE_ID='musictv-tv-focus-v12';
          if(!document.getElementById(STYLE_ID)){
            const s=document.createElement('style'); s.id=STYLE_ID;
            s.textContent=`
              .musictv-focusable:focus, a:focus, button:focus, input:focus, select:focus,
              [role="button"]:focus, [tabindex]:focus {
                outline:5px solid #fff !important;
                box-shadow:0 0 0 5px #fa243c,0 0 34px 10px rgba(250,36,60,.85) !important;
                border-radius:12px !important;
                transform:scale(1.075) !important;
                transition:transform .13s ease,box-shadow .13s ease,background .13s ease !important;
                background-color:rgba(250,36,60,.20) !important;
                position:relative !important; z-index:2147483646 !important;
              }`;
            document.head.appendChild(s);
          }
          const selector='a,button,input,select,[role="button"],[role="link"],[role="menuitem"],[data-testid],li';
          function prep(){
            document.querySelectorAll(selector).forEach(el=>{
              const st=getComputedStyle(el); const r=el.getBoundingClientRect();
              if(st.display!=='none' && st.visibility!=='hidden' && r.width>12 && r.height>12){
                if(!el.hasAttribute('tabindex')) el.setAttribute('tabindex','0');
                el.classList.add('musictv-focusable');
                el.addEventListener('focus',()=>el.scrollIntoView({behavior:'smooth',block:'center',inline:'center'}),{passive:true});
              }
            });
          }
          prep(); new MutationObserver(prep).observe(document.body,{childList:true,subtree:true});
          if(!document.__musicTvKeys){
            document.__musicTvKeys=true;
            document.addEventListener('keydown',e=>{
              const all=[...document.querySelectorAll('.musictv-focusable')].filter(el=>{
                const r=el.getBoundingClientRect(); return r.width>12&&r.height>12;
              });
              if(!all.length) return;
              let cur=document.activeElement; let i=all.indexOf(cur);
              if(['ArrowDown','ArrowRight'].includes(e.key)){ e.preventDefault(); all[Math.min(i<0?0:i+1,all.length-1)].focus(); }
              if(['ArrowUp','ArrowLeft'].includes(e.key)){ e.preventDefault(); all[Math.max(i<=0?0:i-1,0)].focus(); }
              if(e.key==='Enter' && cur && cur.click){ e.preventDefault(); cur.click(); }
            },true);
          }
        })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    private fun setupButtons() {
        binding.loginButton.setOnClickListener { startMusicKitLogin() }
        binding.openMusicButton.setOnClickListener { showPlayer(appleMusicUrl) }
        binding.browserButton.setOnClickListener { openExternal(appleMusicUrl) }
        binding.donateButton.setOnClickListener {
            val url=getString(R.string.donation_url)
            if(url.contains("example.com")) Toast.makeText(this,"Configura tu enlace de donación.",Toast.LENGTH_LONG).show() else openExternal(url)
        }
        binding.backHomeButton.setOnClickListener { showHome() }
    }

    private fun startMusicKitLogin() {
        val developerToken = getString(R.string.developer_token)
        if (developerToken.startsWith("PUT_YOUR")) {
            showMusicKitSetupDialog()
            return
        }
        try {
            val factory = Class.forName("com.apple.android.sdk.authentication.AuthenticationFactory")
            val createManager = factory.getMethod("createAuthenticationManager", android.content.Context::class.java)
            authManager = createManager.invoke(null, this)
            val createIntentBuilder = authManager!!.javaClass.getMethod("createIntentBuilder", String::class.java)
            val builder = createIntentBuilder.invoke(authManager, developerToken)
            val intent = builder.javaClass.getMethod("build").invoke(builder) as Intent
            startActivityForResult(intent, authRequestCode)
        } catch (e: Throwable) {
            showMusicKitSetupDialog()
        }
    }

    private fun showMusicKitSetupDialog() {
        AlertDialog.Builder(this)
            .setTitle("MusicKit necesita configuración")
            .setMessage("El botón de login ya está conectado al flujo oficial de MusicKit. Para activarlo, agrega el SDK de MusicKit para Android en app/libs y coloca tu Developer Token de Apple Music en strings.xml. Después recompila la app.")
            .setPositiveButton("Entendido", null)
            .setNegativeButton("Abrir Apple Music") { _, _ -> showPlayer(appleMusicUrl) }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode != authRequestCode || data == null || authManager == null) return
        try {
            val result = authManager!!.javaClass.getMethod("handleTokenResult", Intent::class.java).invoke(authManager, data)
            val token = result.javaClass.getMethod("getMusicUserToken").invoke(result) as? String
            if(!token.isNullOrBlank()) {
                getSharedPreferences("musictv", MODE_PRIVATE).edit().putString("music_user_token", token).apply()
                Toast.makeText(this,"Apple Music conectado",Toast.LENGTH_LONG).show()
                showPlayer(appleMusicUrl)
            } else Toast.makeText(this,"No se pudo completar el inicio de sesión",Toast.LENGTH_LONG).show()
        } catch(e: Throwable) {
            Toast.makeText(this,"No se pudo leer la autorización de Apple Music",Toast.LENGTH_LONG).show()
        }
    }

    private fun showPlayer(url:String){
        screen="player"; binding.homeScroll.visibility=View.GONE; binding.playerPanel.visibility=View.VISIBLE
        binding.progress.visibility=View.VISIBLE; binding.webView.loadUrl(url); binding.webView.requestFocus()
    }
    private fun showHome(){
        screen="home"; binding.playerPanel.visibility=View.GONE; binding.homeScroll.visibility=View.VISIBLE; binding.loginButton.requestFocus()
    }
    private fun openExternal(url:String){
        try{ startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch(_:ActivityNotFoundException){ Toast.makeText(this,"No hay un navegador compatible instalado.",Toast.LENGTH_LONG).show() }
    }
    override fun onKeyDown(keyCode:Int,event:KeyEvent?):Boolean{
        if(keyCode==KeyEvent.KEYCODE_BACK && screen=="player"){
            if(binding.webView.canGoBack()) binding.webView.goBack() else showHome(); return true
        }
        return super.onKeyDown(keyCode,event)
    }
    override fun onDestroy(){ binding.webView.stopLoading(); binding.webView.destroy(); super.onDestroy() }
}
