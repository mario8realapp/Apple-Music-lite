# MusicTV Lite v1.2

Cambios principales:
- Botón principal “Iniciar sesión con Apple Music”.
- Integración preparada para el SDK oficial MusicKit Authentication.
- Foco de TV mucho más visible: color, borde y escala animada.
- Scroll automático cuando un botón enfocado queda fuera de pantalla.
- Navegación web reforzada: elementos interactivos reciben foco, resaltado y scroll al centro.
- Icono personalizado conservado.
- Donaciones conservadas.

Consulta `MUSICKIT_SETUP.md` para activar el login oficial.
