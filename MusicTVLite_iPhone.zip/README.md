# Music TV Lite

App Android/Google TV ligera para abrir Apple Music desde una interfaz simple y cómoda con control remoto.

## Qué incluye
- Pantalla inicial optimizada para TV.
- Colores rosa/rojo inspirados en Apple Music.
- Botón principal para abrir `music.apple.com` dentro de la app.
- Botón alternativo para abrir Apple Music en el navegador.
- Navegación con control remoto / D-pad.
- Botón inferior: "¿Quieres apoyar el proyecto?" + "Donar lo que quieras".
- Enlace de donación totalmente configurable.
- Sin anuncios ni rastreadores incluidos.

## Configurar la donación
Edita:

`app/src/main/res/values/strings.xml`

y cambia:

`https://example.com/tu-donacion`

por tu URL de PayPal.me, Ko-fi, Buy Me a Coffee u otro servicio.

## Abrir en Android Studio
1. Instala Android Studio.
2. Abre la carpeta `MusicTVLite`.
3. Espera a que Gradle sincronice.
4. Conecta tu Xiaomi Google TV con depuración ADB o genera un APK.
5. `Build > Build APK(s)`.

## Importante sobre Apple Music
Esta versión usa la web oficial `music.apple.com` para evitar incluir claves privadas de Apple dentro del proyecto.

La reproducción dentro de WebView puede depender de la versión de Android System WebView, Widevine/DRM y del firmware de tu TV. Por eso también se incluye "Abrir en navegador" como alternativa.

Para una versión 100% nativa con catálogo, biblioteca y reproducción usando MusicKit para Android, se necesita una cuenta de Apple Developer y configurar autenticación/token de MusicKit.

## Marca
Este proyecto es no oficial y no está afiliado, patrocinado ni aprobado por Apple Inc. No incluye logos ni recursos gráficos propietarios de Apple.

## Compilar el APK sin Android Studio usando GitHub

El proyecto ya incluye `.github/workflows/build-apk.yml`.

1. Crea un repositorio nuevo en GitHub.
2. Sube TODO el contenido de la carpeta `MusicTVLite`, incluyendo la carpeta oculta `.github`.
3. En GitHub abre la pestaña **Actions**.
4. Entra a **Compilar APK para Google TV**.
5. Si no se ejecutó automáticamente, pulsa **Run workflow**.
6. Cuando termine, abre la ejecución y baja hasta **Artifacts**.
7. Descarga **MusicTVLite-APK**.
8. Descomprime ese archivo y encontrarás `MusicTVLite.apk`.
9. Pasa `MusicTVLite.apk` a tu Xiaomi Google TV e instálalo.

Si GitHub muestra una advertencia para habilitar Actions en un repositorio nuevo, habilítalas y vuelve a ejecutar el workflow.
