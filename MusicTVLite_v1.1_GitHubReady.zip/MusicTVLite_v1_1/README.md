# MusicTV Lite v1.1

Novedades:
- Icono personalizado.
- Banner para Google TV.
- Selección/foco mucho más visible.
- Resaltado dentro de Apple Music Web.
- Acceso rápido por QR.
- Botón para abrir el login en TV.
