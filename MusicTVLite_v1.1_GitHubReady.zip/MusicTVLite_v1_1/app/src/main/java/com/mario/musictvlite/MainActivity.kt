package com.mario.musictvlite

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mario.musictvlite.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val appleMusicUrl = "https://music.apple.com/"
    private val appleLoginUrl = "https://music.apple.com/us/login"
    private var screen = "home"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setupWebView()
        setupButtons()
        binding.openMusicButton.requestFocus()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(binding.webView, true)
        binding.webView.apply {
            setBackgroundColor(Color.BLACK)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    binding.progress.visibility = View.GONE
                    injectTvFocusStyle()
                    super.onPageFinished(view, url)
                }
            }
            webChromeClient = WebChromeClient()
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                cacheMode = WebSettings.LOAD_DEFAULT
                loadsImagesAutomatically = true
                builtInZoomControls = false
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                userAgentString = userAgentString.replace("; wv", "")
            }
        }
    }

    private fun injectTvFocusStyle() {
        val js = """
            (function() {
              if (document.getElementById('musictv-focus-style')) return;
              const style = document.createElement('style');
              style.id = 'musictv-focus-style';
              style.innerHTML = `
                a:focus, button:focus, input:focus, select:focus,
                [role="button"]:focus, [tabindex]:focus {
                  outline: 5px solid #ffffff !important;
                  box-shadow: 0 0 0 4px #fa243c, 0 0 24px 8px rgba(250,36,60,.75) !important;
                  border-radius: 10px !important;
                  transform: scale(1.035) !important;
                  transition: all .12s ease !important;
                  z-index: 999999 !important;
                }
              `;
              document.head.appendChild(style);
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    private fun setupButtons() {
        binding.openMusicButton.setOnClickListener { showPlayer(appleMusicUrl) }
        binding.qrLoginButton.setOnClickListener { showQr() }
        binding.browserButton.setOnClickListener { openExternal(appleMusicUrl) }
        binding.openLoginTvButton.setOnClickListener { showPlayer(appleLoginUrl) }
        binding.backFromQrButton.setOnClickListener { showHome() }
        binding.donateButton.setOnClickListener {
            val donationUrl = getString(R.string.donation_url)
            if (donationUrl.contains("example.com")) {
                Toast.makeText(this, "Configura tu enlace de donación en strings.xml", Toast.LENGTH_LONG).show()
            } else {
                openExternal(donationUrl)
            }
        }
        binding.backHomeButton.setOnClickListener { showHome() }
    }

    private fun showPlayer(url: String) {
        screen = "player"
        binding.homePanel.visibility = View.GONE
        binding.qrPanel.visibility = View.GONE
        binding.playerPanel.visibility = View.VISIBLE
        binding.progress.visibility = View.VISIBLE
        binding.webView.loadUrl(url)
        binding.webView.requestFocus()
    }

    private fun showQr() {
        screen = "qr"
        binding.homePanel.visibility = View.GONE
        binding.playerPanel.visibility = View.GONE
        binding.qrPanel.visibility = View.VISIBLE
        binding.openLoginTvButton.requestFocus()
    }

    private fun showHome() {
        screen = "home"
        binding.playerPanel.visibility = View.GONE
        binding.qrPanel.visibility = View.GONE
        binding.homePanel.visibility = View.VISIBLE
        binding.openMusicButton.requestFocus()
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "No hay un navegador compatible instalado.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            when (screen) {
                "player" -> {
                    if (binding.webView.canGoBack()) binding.webView.goBack() else showHome()
                    return true
                }
                "qr" -> {
                    showHome()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        binding.webView.apply {
            stopLoading()
            webChromeClient = null
            webViewClient = WebViewClient()
            destroy()
        }
        super.onDestroy()
    }
}
